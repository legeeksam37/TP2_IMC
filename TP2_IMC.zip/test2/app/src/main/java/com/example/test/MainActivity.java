package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button envoyer = null;
    Button reset = null;
    EditText taille = null;
    EditText poids = null;
    CheckBox commentaire = null;
    RadioGroup group = null;
    TextView result = null;
    /*Quelques string à utiliser dans l'application depuis le fichier string.xml*/
    String oms ;
    String os ;
    String om ;
    String sp ;
    String cn ;
    String maigreur;
    String famine;

    private final String texteInit = "Cliquez sur le bouton « Calculer l'IMC » pour obtenir un résultat.";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Composants
         envoyer = (Button) findViewById(R.id.calcul);
         reset = (Button) findViewById(R.id.reset);
        taille = (EditText) findViewById(R.id.taille);
         poids = (EditText) findViewById(R.id.poids);
        commentaire = (CheckBox) findViewById(R.id.commentaire);
        group = (RadioGroup) findViewById(R.id.group);
        result = (TextView) findViewById(R.id.result);
        envoyer.setOnClickListener(envoyerListener);
        reset.setOnClickListener(resetListener);
        taille.addTextChangedListener(tw);
        oms = getString(R.string.oms);
        os = getString(R.string.os);
        om = getString(R.string.om);
        sp = getString(R.string.sp);
        cn = getString(R.string.cn);
        maigreur = getString(R.string.maigreur);
        famine = getString(R.string.famine);







    }


    private View.OnClickListener resetListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            poids.getText().clear();
            taille.getText().clear();
            result.setText(texteInit);
        }
    };

   /* private View.OnClickListener envoyerListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //Récupère le poids et la masse
            String t = taille.getText().toString();
            String p = poids.getText().toString();
            //converti en nombre
            float tValeur = Float.valueOf(t);
            float pValeur = Float.valueOf(p);
            float imc = 0;
            String resultat = "";
            //Vérification de la cohérence et calcul imc
            if (tValeur >= 0 && pValeur >= 0) {
                //algo
                Toast.makeText(MainActivity.this, "Votre imc "+ imc, Toast.LENGTH_SHORT).show();
               if (group.getCheckedRadioButtonId() == R.id.radio_centimetre) {
                    tValeur =  (tValeur / 100);
                    imc = pValeur/ (tValeur * tValeur);
                    resultat = "Votre IMC est " + imc + " . ";
                    result.setText(resultat);

                    }

                    if (t.contains(".")||t.contains(","))
                        group.check(R.id.radio_metre);

                else if (group.getCheckedRadioButtonId() == R.id.radio_metre  || (t.contains(".")||t.contains(","))) {
                    imc = pValeur / (tValeur * tValeur);
                    resultat = "Votre IMC est " + imc + " . ";
                    result.setText(resultat);
                }

                if(commentaire.isChecked()) resultat += interpreteIMC(imc);

            } else {
                Toast.makeText(MainActivity.this, "Le poids et la taille doivent être positifs", Toast.LENGTH_SHORT).show();

            }


        }
    };*/


    private View.OnClickListener envoyerListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            //  on récupère la taille
            String t = taille.getText().toString();
            // On récupère le poids
            String p = poids.getText().toString();
            float tValue = Float.valueOf(t);

            // Puis on vérifie que la taille est cohérente
            if(tValue <= 0)
                Toast.makeText(MainActivity.this, "La taille doit être positive", Toast.LENGTH_SHORT).show();
            else {
                float pValue = Float.valueOf(p);
                if(pValue <= 0)
                    Toast.makeText(MainActivity.this, "Le poids doit etre positif", Toast.LENGTH_SHORT).show();
                else {
                    // Si l'utilisateur a indiqué que la taille était en centimètres
                    // On vérifie que la Checkbox sélectionnée est la deuxième à l'aide de son identifiant
                    if (group.getCheckedRadioButtonId() == R.id.radio_centimetre) tValue = tValue / 100;
                    float imc = pValue / (tValue * tValue);
                    String resultat="Votre IMC est " + imc+" . ";

                    result.setText(resultat);
                    if(commentaire.isChecked()) resultat += interpreteIMC(imc);
                }
            }
        }
    };


    private String interpreteIMC(float imc) {
        //comparaison de la valeur de l'IMC avec les critères
        if (imc <= 16.5) {
            result.setText(famine);
        } else if (imc >= 16.5 && imc <= 18.5) {
            result.setText(maigreur);
        } else if (imc >= 18.5 && imc <= 25) {
            result.setText(cn);
        } else if (imc >= 25 && imc <= 30) {
            result.setText(sp);
        } else if (imc >= 30 && imc <= 35) {
            result.setText(om);
        } else if (imc >= 35 && imc <= 40) {
            result.setText(os);
        } else if (imc >= 40) {
            result.setText(oms);
        }

        return null;

    }


    //changing the value with textWatcher

    TextWatcher tw = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {



        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if(taille.getText().toString().contains(".") && group.getCheckedRadioButtonId() == R.id.radio_centimetre)
                group.check(R.id.radio_metre);
            result.setText(texteInit);

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

}

